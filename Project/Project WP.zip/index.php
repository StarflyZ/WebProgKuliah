<!DOCTYPE html>
<html>
  <head>
    <title>Contoh Halaman Website</title>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>
    <style>
      body {
        font-family: Arial, sans-serif;
        background: #c31432;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #240b36, #c31432);  /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to right, #240b36, #c31432); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */


      }

      h1 {
        text-align: center;
        color: #333;
      }

      .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
      }
      .person {
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        display: inline-block;
        margin: 20px;
        text-align: center;
      }

      .person img {
        width: 200px;
        height: 200px;
        border-radius: 50%;
        margin-bottom: 10px;
      }

      .person h2 {
        color: #333;
      }

      .button-container {
        text-align: center;
        margin-top: 50px;
      }
    

      button {
        padding: 10px 20px;
        font-size: 16px;
        color: #fff;
        background-color: #333;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: all 0.3s ease;
      }

      button:hover {
        background-color: #555;
      }
      button:active {
        transform: translateY(2px);
      }
    </style>

    <h1>Selamat Datang di Website Kami!</h1>
    <div class="container">
      <div class="person">
        <img src="Foto DIri.jpeg" alt="Steven Nataniel">
        <h2>Steven Nataniel - 160421041</h2>
      </div>
      <div class="person">
        <img src="160421132_l.jpg" alt="Foto Orang Kedua">
        <h2>Timotius Setiawan - 160421132</h2>
      </div>
      <div class="person">
        <img src="160821028_l.jpg" alt="Foto Orang Ketiga">
        <h2>Jason Daniel Johan - 160821028</h2>
      </div>
    </div>
    <div class="button-container">
      <a href="setting.php"><button>Setting</button></a>
      <a href="input.php"><button>Input</button></a>
      <a href="display.php"><button>Display</button></a>
    </div>
  </body>
</html>
