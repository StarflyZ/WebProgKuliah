<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input</title>
</head>
<body>
<style>
    
    body{
        margin: 0;
        padding: 0;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        background: #1a2a6c;
        background: -webkit-linear-gradient(to right, #fdbb2d, #b21f1f, #1a2a6c); 
        background: linear-gradient(to right, #fdbb2d, #b21f1f, #1a2a6c); 
        height: 100vh;
        overflow: hidden;
    }
    .center{
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 400px;
        background: white;
        border-radius: 10px;
    }
    .center h1{
        text-align: center;
        padding: 0 0 20px 0;
        border-bottom: 1px solid silver;
    }
    .center form{
        padding: 0 40px;
        box-sizing: border-box;
    }
    form .txt_field{
        position: relative;
        border-bottom: 2px solid #adadad;
        margin: 30px 0;
    }
    .txt_field input{
        width: 100%;
        padding: 0 5px;
        height: 40px;
        font-size: 16px;
        border: none;
        background: none;
        outline: none;
    }
    .txt_field label{
        position: absolute;
        top: 50%;
        left: 5px;
        color: #adadad;
        transform: translateY(-50%);
        font-size: 16px;
        pointer-events: none;
        transition: .4s;
    }
    .txt_field span::before{
        content: '';
        position: absolute;
        top: 40px;
        left: 0;
        width: 100%;
        height: 2px;
        background: #2691d9;
    }
    .txt_field input:focus ~ label,
    .txt_field input:focus ~ label{
        top: -5px;
        color: #2691d9;
    }
    input[type="submit"]{
        position: center;
        width: 100%;
        height: 50px;
        border: 1px solid;
        background: #2691d9;
        border-radius: 25px;
        font-size: 18px;
        color: #e9f3fb;
        font-weight: 700;
        cursor: pointer;
        outline: none;
    }
    input[type="submit"]:hover{
        border-color: #2691d9;
        transition: .4s;
    }
    
</style>
    <div class="center">
        <h1>Input Data Mahasiswa</h1>
        <form method="POST" action="input_proses.php">
            <div class="txt_field">
                <input type="nrp" name="nrp" required autofocus><br>
                <span></span>
                <label>Masukan NRP</label>
            </div>
            <div class="txt_field">
                <input type="nama" name="nama" required><br>
                <span></span>  
                <label>Masukan Nama</label>
            </div>
            <div class="txt_field">
                <input type="alamat" name="alamat" required><br>
                <span></span>                 
                <label>Masukan Alamat</label>
            </div>      
            <div class="txt_field">
                <input type="ipk" name="ipk" required><br>
                <span></span>         
                <label>Masukan IPK</label>
            </div>    
            <div class="btn_Submit">
                <input type="submit" name="submit" value="simpan">
            </div>   
            </div>
        </form>
    </div>
</body>
</html>